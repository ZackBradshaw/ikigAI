import discord
import os
import json
import time
from discord.ext import tasks
from discord import Embed
from colorama import Fore

# Auto-ikigAI Persona Description
AUTOIKIGAI_PERSONA = """[Quest]SENSEI ADOPTS ROLE... (as described in your prompt)"""

description = "An AutoGPT discord bot that allows users to interact with their AutoGPT instance through discord."

intents = discord.Intents.default()
intents.members = True
intents.message_content = True

BOT_TOKEN = os.getenv("DISCORD_BOT_TOKEN")
AUTHORIZED_USER_IDS = os.getenv("AUTHORIZED_USER_IDS").split(",")
BOT_PREFIX = os.getenv("BOT_PREFIX")
CHANNEL_ID = os.getenv("CHANNEL_ID")

userReply = []
messagesToSend = []
waitingForReply = [False]


class Message(dict):
    role: str
    content: str

# Define a function to summarize and personalize JSON data


def summarize_and_personalize(json_data):
    summary = "Dear Seeker, here's a reflection of your journey:\n"
    for key, value in json_data.items():
        summary += f"- {key}: {value}\n"
    summary += "Embrace the challenges, align your passions, and grow with resilience. 🤖"
    return summary

# Define the autoGPTMessageEmbed function


def autoGPTMessageEmbed(message):
    embed = Embed(title="Auto-ikigAI Guidance", color=0x00ff00)
    embed.description = summarize_and_personalize(
        json.loads(message["content"]))
    embed.set_footer(text="Guidance from Auto-ikigAI 🤖")
    return embed


class AutoGPT_Discord(discord.Client):
    async def on_ready(self):
        print(Fore.GREEN +
              f'Bot logged in as {self.user} (ID: {self.user.id})')
        print(Fore.GREEN + '------')

    async def setup_hook(self) -> None:
        self.background.start()

    @tasks.loop(seconds=1)
    async def background(self):
        channel = self.get_channel(int(CHANNEL_ID))
        if len(messagesToSend) > 0:
            for message in messagesToSend:
                try:
                    await channel.send(embed=autoGPTMessageEmbed(message))
                except:
                    # Handle exceptions ...
                    pass
                messagesToSend.remove(message)
        if waitingForReply[0]:
            def check(m):
                return str(m.author.id) in AUTHORIZED_USER_IDS and m.channel == channel

            print(Fore.YELLOW + "Waiting for user to reply via discord...")
            user_input = await self.wait_for("message", check=check)

            print(Fore.GREEN + "User replied: " + user_input.content)

            userReply.append(user_input.content)

            waitingForReply[0] = False

    async def on_message(self, message):
        if message.author.id == self.user.id:
            return

        if message.content.startswith(BOT_PREFIX + "shutdown") and str(message.author.id) in AUTHORIZED_USER_IDS:
            await message.reply(embed=shutdownEmbed("AutoGPT Discord Bot going back to sleep. Bye!"))
            os._exit(0)
        elif message.content.startswith(BOT_PREFIX + "shutdown"):
            await message.reply(embed=shutdownEmbed("You aren't authorized dummy >:("))

    @background.before_loop
    async def before_my_task(self):
        await self.wait_until_ready()


def run_bot():
    global client
    client = AutoGPT_Discord(intents=intents)
    client.run(BOT_TOKEN)


def wait_for_user_input(name, args):
    messagesToSend.append(
        Message(role="REQUEST", content=json.dumps({'name': name, 'args': args})))
    waitingForReply[0] = True
    while waitingForReply[0]:
        time.sleep(1)
    if userReply[0].lower() == "y":
        userReply.pop(0)
        return "Authorized"
    if userReply[0].lower() == "n":
        userReply.pop(0)
        return "Unauthorized"
    else:
        return userReply.pop(0)


# Running the bot
run_bot()
